import logo from './logo.svg';
import Board from './Board';
import './App.css';

function App() {
  return (
    <div className="App">
      <Board />
    </div>
  );
}

export default App;
