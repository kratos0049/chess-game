import React, { useEffect, useRef, useState } from "react";
import PropTypes from "prop-types";
import { Chess } from "chess.js"; // import Chess from  "chess.js"(default) if recieving an error about new Chess() not being a constructor

import Chessboard from "chessboardjsx";
import ScoreSheet from "../src/ScoreSheet";

export default function Board(){
  const game = useRef(null);
  useEffect(()=>{
    game.current = new Chess();
  }, [])
  
  
  const [fen, changeFen]=useState("start");
  const [history, changeHistory] = useState([]);
  const [squareStyles, changeSquareStyles] = useState({});
  const [pieceSquare, changePieceSquare]=useState("");
  const [dropSquareStyle, changeDropSquareStyle]= useState({});
  const [whiteMoves, addWhiteMove]= useState([]);
  const [blackMoves, addBlackMove]= useState([]);

  useEffect(()=>{
  }, [squareStyles])
  

  const highlightSquare = (sourceSquare, squaresToHighlight) => {
    const highlightStyles = [sourceSquare, ...squaresToHighlight].reduce(
      (a, c) => {
        return {
          ...a,
          ...{
            [c]: {
              background:
                "radial-gradient(circle, #fffc00 36%, transparent 40%)",
              borderRadius: "30%"
            }
          },
          ...squareStyling({
            history: history,
            pieceSquare: pieceSquare
          })
        };
      },
      {}
    );
    changeSquareStyles({...highlightStyles })
    
  };
  
  const squareStyling = ({ pieceSquare, history }) => {
    const sourceSquare = history.length && history[history.length - 1].from;
    const targetSquare = history.length && history[history.length - 1].to;
  
    return {
      [pieceSquare]: { backgroundColor: "rgba(255, 255, 0, 0.4)" },
      ...(history.length && {
        [sourceSquare]: {
          backgroundColor: "rgba(255, 255, 0, 0.4)"
        }
      }),
      ...(history.length && {
        [targetSquare]: {
          backgroundColor: "rgba(255, 255, 0, 0.4)"
        }
      })
    };
    
  };

  
  const onDrop = ({ sourceSquare, targetSquare, piece }) => {
    
    // see if the move is legal
    let move = game.current.move({
      from: sourceSquare,
      to: targetSquare,
      promotion: "q" // always promote to a queen for example simplicity
    });
    // illegal move
    if (move === null) return;

    if(piece.slice(0,1)=='w'){
      addWhiteMove([...whiteMoves,piece.slice(1)+targetSquare]);
    }
    else{
      addBlackMove([...blackMoves,piece.slice(1)+targetSquare]);
    }
    changeFen(game.current.fen)
    changeHistory(game.current.history({verbose:true}))
    changeSquareStyles(squareStyling({ pieceSquare, history }))
  
  }

  const onMouseOverSquare = square => {
    // get list of possible moves for this square
    let moves = game.current.moves({
      square: square,
      verbose: true
    });

    // exit if there are no moves available for this square
    if (moves.length === 0) return;

    let squaresToHighlight = [];
    for (var i = 0; i < moves.length; i++) {
      squaresToHighlight.push(moves[i].to);
    }

    highlightSquare(square, squaresToHighlight);
  };

   // keep clicked square style and remove hint squares
   const removeHighlightSquare = () => {
      changeSquareStyles({})
    };

    const onMouseOutSquare = square => {
      removeHighlightSquare(square);
    }

    const onSquareRightClick = square =>{
      changeSquareStyles({ [square]: { backgroundColor: "deepPink" } })
    }

    const onSquareClick = square => {
        
          changeSquareStyles(squareStyling({ pieceSquare: square, history }))
          changePieceSquare(square)
        
    
        let move = game.current.move({
          from: pieceSquare,
          to: square,
          promotion: "q" // always promote to a queen for example simplicity
        });
    
        // illegal move
        if (move === null) return;

        changeFen(game.current.fen())
        changeHistory(game.current.history({ verbose: true }))
        changePieceSquare("") 
      };


      const onDragOverSquare = square => {
      
          changeDropSquareStyle(
            square === "e4" || square === "d4" || square === "e5" || square === "d5"
              ? { backgroundColor: "cornFlowerBlue" }
              : { boxShadow: "inset 0 0 1px 4px rgb(255, 255, 0)" }
          )
      };
    

  return (
    <>
          <Chessboard
            id="humanVsHuman"
            width={700}
            position={fen}
            onDrop = {onDrop}
            onMouseOverSquare = {onMouseOverSquare}
            onMouseOutSquare = {onMouseOutSquare}
            boardStyle={{
              borderRadius: "5px",
              boxShadow: `0 5px 15px rgba(0, 0, 0, 0.5)`
            }}
            squareStyles = {squareStyles}
            dropSquareStyle={dropSquareStyle}
            onDragOverSquare = {onDragOverSquare}
            onSquareClick={onSquareClick}
            onSquareRightClick={onSquareRightClick}
          />
            <br/>
            <br/>
            
          <ScoreSheet whiteMoves={whiteMoves} blackMoves= {blackMoves} />
    </>
  );
}

